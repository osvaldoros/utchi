<?php

require_once('lib/generator/file/Freezer.php');