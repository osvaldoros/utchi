dojoCdnTestLog.push("defining-dojo.tests._base.loader.amdModule");
define(["./amdModuleDep"], function(){
	dojoCdnTestLog.push("factory-dojo.tests._base.loader.amdModule");
	return {status:"OK"};
});
