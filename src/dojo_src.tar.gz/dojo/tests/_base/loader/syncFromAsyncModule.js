dojo.provide("dojo.tests._base.loader.syncFromAsyncModule");
dojo.declare("dojo.tests._base.loader.syncFromAsyncModule", null, {});
dojo.tests._base.loader.syncFromAsyncModule.status= "OK";
dojo.require("dojo.tests._base.loader.syncFromAsyncModuleDep");
