dojo.provide("myTopLevelModule");
dojo.require("myTopLevelModule.myModule");
myTopLevelModule.name= "myTopLevelModule";