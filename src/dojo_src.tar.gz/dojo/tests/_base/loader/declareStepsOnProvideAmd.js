define(["./declareStepsOnProvide"], function(result){
	return result;
});
