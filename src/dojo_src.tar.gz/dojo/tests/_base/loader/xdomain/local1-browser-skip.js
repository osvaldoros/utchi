xdomainExecSequence.push("dojo.tests._base.loader.xdomain.local1-browser-skip-1");
