xdomainExecSequence.push("dojo.tests._base.loader.xdomain.local1-browser-1");
var x1= dojo.provide("dojo.tests._base.loader.xdomain.local1-browser");
dojo.getObject("dojo.tests._base.loader.xdomain.local1-browser").status= "dojo.tests._base.loader.xdomain.local1-browser-ok";
xdomainExecSequence.push("dojo.tests._base.loader.xdomain.local1-browser-2");
