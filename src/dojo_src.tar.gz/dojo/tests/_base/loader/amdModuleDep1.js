dojoCdnTestLog.push("defining-dojo.tests._base.loader.amdModuleDep1");
define([], function(){
	dojoCdnTestLog.push("factory-dojo.tests._base.loader.amdModuleDep1");
	return {status:"OK"};
});
