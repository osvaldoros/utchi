dojoCdnTestLog.push("defining-dojo.tests._base.loader.amdModuleDep");
define([], function(){
	dojoCdnTestLog.push("factory-dojo.tests._base.loader.amdModuleDep");
	return {status:"OK"};
});
