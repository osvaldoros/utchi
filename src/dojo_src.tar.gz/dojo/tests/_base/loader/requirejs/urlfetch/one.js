var one = {
    name: "one"
};
