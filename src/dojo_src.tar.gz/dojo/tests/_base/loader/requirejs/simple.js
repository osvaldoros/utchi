define("simple",
  function() {
    return {
      color: "blue"
    };
  }
);
