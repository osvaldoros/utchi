// alias i18n to dojo/i18n
define(["dojo/i18n"], function(i18n){
  return i18n;
});