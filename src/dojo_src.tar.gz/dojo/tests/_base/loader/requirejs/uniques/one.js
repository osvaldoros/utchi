define(function (require) {
    return {
       name: "one",
       threeName: require("three").name,
       threeName2: require("three").name
    };
});

