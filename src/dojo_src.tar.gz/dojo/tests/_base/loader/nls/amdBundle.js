define({
	root:{
		amdBundle:"amdBundle"
	},
	ab:1,
	"ab-cd-ef":1
});
