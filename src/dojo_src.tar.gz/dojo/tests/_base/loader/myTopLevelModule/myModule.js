dojo.provide("myTopLevelModule.myModule");
myTopLevelModule.myModule.name= "myTopLevelModule.myModule";