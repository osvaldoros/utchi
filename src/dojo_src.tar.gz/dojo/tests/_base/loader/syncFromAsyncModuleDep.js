dojo.provide("dojo.tests._base.loader.syncFromAsyncModuleDep");
dojo.tests._base.loader.syncFromAsyncModuleDep.status= "OK";
