dojoCdnTestLog.push("in-dojo.tests._base.loader.syncModuleDep");
dojo.provide("dojo.tests._base.loader.syncModuleDep");
dojo.tests._base.loader.syncModuleDep.status= "OK";
dojoCdnTestLog.push("out-dojo.tests._base.loader.syncModuleDep");
