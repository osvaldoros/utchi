dojoCdnTestLog.push("in-dojo.tests._base.loader.syncModuleDep1");
dojo.provide("dojo.tests._base.loader.syncModuleDep1");
dojo.tests._base.loader.syncModuleDep1.status= "OK";
dojoCdnTestLog.push("out-dojo.tests._base.loader.syncModuleDep1");
