dojoCdnTestLog.push("defining-dojo.tests._base.loader.amdModule2");
define(["./amdModuleDep"], function(){
	dojoCdnTestLog.push("factory-dojo.tests._base.loader.amdModule2");
	return {status:"OK"};
});
