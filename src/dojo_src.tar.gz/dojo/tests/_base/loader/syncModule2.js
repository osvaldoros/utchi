dojoCdnTestLog.push("in-dojo.tests._base.loader.syncModule2");
dojo.provide("dojo.tests._base.loader.syncModule");
dojo.tests._base.loader.syncModule.status= "OK";
dojo.require("dojo.tests._base.loader.syncModuleDep");
dojoCdnTestLog.push("out-dojo.tests._base.loader.syncModule2");
