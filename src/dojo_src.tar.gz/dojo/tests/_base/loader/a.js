define({
	number: 42
});