define({
	greeting: "Hello",
	five: 5
});