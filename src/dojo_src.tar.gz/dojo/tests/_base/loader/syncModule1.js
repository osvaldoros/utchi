dojoCdnTestLog.push("in-dojo.tests._base.loader.syncModule1");
dojo.provide("dojo.tests._base.loader.syncModule1");
dojo.tests._base.loader.syncModule1.status= "OK";
dojo.require("dojo.tests._base.loader.syncModuleDep1");
dojoCdnTestLog.push("out-dojo.tests._base.loader.syncModule1");
