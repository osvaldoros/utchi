define(
//begin v1.x content
{
 de: "Deutsch",
 hello: "Hallo"
}
//end v1.x content
);
