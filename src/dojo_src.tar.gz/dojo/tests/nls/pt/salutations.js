define(
//begin v1.x content
{
 pt: "Português",
 hello: "Olá"
}
//end v1.x content
);
