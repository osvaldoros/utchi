define(
//begin v1.x content
{
 tr: "Türkçe",
 hello: "Merhaba"
}
//end v1.x content
);
