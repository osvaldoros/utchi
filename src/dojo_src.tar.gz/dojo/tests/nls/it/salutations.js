define(
//begin v1.x content
{
 it: "italiano",
 hello: "Ciao"
}
//end v1.x content
);
