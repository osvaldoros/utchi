define(
//begin v1.x content
{
 he: "עברית",
 hello: "שלום"
}
//end v1.x content
);
