define(
//begin v1.x content
{
 el: "Ελληνικά",
 hello: "Γειά"
}
//end v1.x content
);
