define(
//begin v1.x content
{
 yi: "ייִדיש",
 hello: "אַ גוטן טאָג"
}
//end v1.x content
);
